import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class splashForm extends JFrame
{
	private JButton exitButton, addButton, loadButton;
	private JTable dataTable;
	private JPanel tblPanel;
	private JScrollPane scrlPane;
	private JTextField txtMovieName;
	private JLabel lblMovieNotes, lblMovieName;
	private JLabel lblTitle;
	private JTextArea txtMovieNotes;
	final FlowLayout myLayOut = new FlowLayout(FlowLayout.CENTER);
	
	public void startForm() throws SQLException 
	{
	
		

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		setLayout(myLayOut);			
		setSize(650, 650);	
		
	
		
		lblTitle= new JLabel("Expense Application", JLabel.CENTER);
		lblTitle.setPreferredSize(new Dimension(650, 35));
		lblTitle.setFont(new Font("Arial", Font.PLAIN, 16));
		add(lblTitle);			
		
		//ADD CHARITY INFO TO TABLE OR DB BUTTON
		loadButton = new JButton("NEW RECORD");
		loadButton .setPreferredSize(new Dimension(600, 50));
//		loadButton.addActionListener(frmEvents);
		add(loadButton);
					
		

											
		//DATA TABLE AND SCROLL PANE
		dataTable = new JTable(new DefaultTableModel(null, new Object[]{ "ID", "USER", "CREATE_DT"}));
		dataTable.setColumnSelectionAllowed( true );
		dataTable.getColumnModel().getColumn(1).setPreferredWidth(110);
		dataTable.getColumnModel().getColumn(2).setPreferredWidth(300);
//		dataTable.addMouseListener(frmMouseEvents);
		scrlPane = new JScrollPane(dataTable);
							
		//PANEL TO PUT THE STUFF ON
		tblPanel = new JPanel();
		tblPanel.setLayout( new BorderLayout() );
		tblPanel.setPreferredSize(new Dimension(600, 200));
		tblPanel.add(scrlPane, BorderLayout.CENTER);
		add( tblPanel );					

		//EXIT BUTTON
		exitButton = new JButton("EXIT");			
		exitButton.setPreferredSize(new Dimension(600, 50));						
//		exitButton.addActionListener(frmEvents);
		add(exitButton, BorderLayout.SOUTH);

		//SET UP THE SQL CLASS
		
		loadTable();
		//LAUNCH THE FORM
		setVisible(true);			
	}
	
	public void loadTable() throws SQLException 
	{
		sqlHandler sqls = new sqlHandler();
		DefaultTableModel tblModel = (DefaultTableModel) dataTable.getModel();
		ResultSet rs = sqls.sqlSelect("SELECT * FROM " + sqls.HEADER_TABLE);
		try 
		{
			while (rs.next())
			{
			 	tblModel.addRow(new Object[]{ rs.getString(sqls.KEY_ROWID) , rs.getString(sqls.USER) , rs.getString(sqls.CREATE_DT) });
			}
		} 
		catch (SQLException e1) 
		{
			e1.printStackTrace();
		}
	}




}
